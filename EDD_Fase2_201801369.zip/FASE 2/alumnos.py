from ESTRUCTURAS_.ArbolAVL import ArbolAVL_
from ESTRUCTURAS_.ARBOLB_.BTree import BTree

Alumnos_ = ArbolAVL_()
Pensum = BTree()