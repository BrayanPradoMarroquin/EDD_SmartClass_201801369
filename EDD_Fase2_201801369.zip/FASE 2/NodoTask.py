class Tareas:
    def __init__(self, carnet, Nombre, Descripcion, Materia, Fecha, Hora, Estado):
        self.id =  0
        self.carnet = carnet
        self.nombre = Nombre
        self.descripcion = Descripcion
        self.materia = Materia
        self.fecha = Fecha
        self.hora = Hora
        self.status = Estado
        self.direccionamiento = None
        self.siguiente = None