from ESTRUCTURAS_.Matriz import *

class NodoMatriz:
    def __init__(self):
        self.filas = Listacabecera()
        self.columna = Listacabecera()
        self.data = ListaData()